#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "includes/Dobby/dobby.h"
#include "Color.h"
#include "Includes/Macros.h"
#include "imgui.h"
#include "box_shadow.cpp"
#include "imgui_internal.h"
#include "Bools_Hooks.h"
#include "Chams.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#define targetLibName OBFUSCATE("libil2cpp.so")
#define libNames OBFUSCATE("libil2cpp.so")
#include "ByNameModding/BNM.hpp"
using namespace BNM;
int glHeight, glWidth;
bool setup;
uintptr_t address;

bool pg1 = true;
bool pg2 = false;
bool pg3 = false;
bool pg4 = false;
bool pg5 = false;
bool pg6 = false;

float scaleEz = 1.75f;

bool openMenuuuu = true;

bool test1, test2, test3 = false;

bool flCheck = false;
bool clCheck = false;

bool abanCheck = false;
bool norecCheck = false;
bool moneyCheck = false;
bool unlCheck = false;

bool isBypassed = false;

int aimfov = 90;
int norec = 0;

int wait1 = 300;
int wait2 = 75;

int menux = 800;
int menuy = 600;



static int knifern = 0;
const char* knifetypes[] = {"Disable", "Karambit", "M9 Bayonet"};



static int karambitrn = 0;
const char* karambittype[] = { "None", "Dragon Glass","Gold", "Universe","Scratch", "Claw"};

static int m9rn = 0;
const char* m9type[] = { "None", "Dragon Glass","Ancient", "Universe","Scratch", "Blue Blood", "Digital Burst", "Kumo", "Frozen"};



float winalpha = 1.0f;

void AntiBan(){
	hexPatches.Aban1.Modify();
	hexPatches.Aban2.Modify();
	hexPatches.Aban3.Modify();
	hexPatches.Aban4.Modify();
	hexPatches.Aban5.Modify();
	hexPatches.Aban6.Modify();
}



void DrawMenu(){
	if(openMenuuuu){
		
    auto& Style = ImGui::GetStyle();
    
    Style.Colors[ImGuiCol_Button] = ImVec4(0, 0, 0, 0.0f);
    Style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0, 0, 0, 0.0f);
    Style.Colors[ImGuiCol_ButtonActive] = ImVec4(0, 0, 0., 0.0f);
		
        ImGui::SetNextWindowSize(ImVec2(menux, menuy), ImGuiCond_Once);
		
		if(!ImGui::Begin(OBFUSCATE("by @root_kalina"), NULL, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar)){
			ImGui::End();
			return;
		}
			
			ImVec2 Q1, Q2;
			ImDrawList* qDrawList;
			const auto& qCurrentWindowPos = ImGui::GetWindowPos();
			const auto& qWindowDrawList = ImGui::GetWindowDrawList();
			const auto& qBackgroundDrawList = ImGui::GetBackgroundDrawList();
			const auto& qForegroundDrawList = ImGui::GetForegroundDrawList();
			
			Q1 = ImVec2(160, -20);
			Q1.x += qCurrentWindowPos.x;
			Q1.y += qCurrentWindowPos.y;
			Q2 = ImVec2(162, 700);
			Q2.x += qCurrentWindowPos.x;
			Q2.y += qCurrentWindowPos.y;
			qDrawList = qWindowDrawList;
			qDrawList->AddRectFilled(Q1, Q2, ImColor(38, 38, 38), 20);
			
			
			ImGui::SetCursorPos(ImVec2(15, 15));
			ImGui::TextColored(ImColor(255, 140, 0), "Septiflight");
            
            ImGui::SetCursorPos(ImVec2(5, 65));
            ImGui::BeginChild(1, ImVec2(145, 500), false);
                
                if(ImGui::CollapsingHeader("Legit")){
                    if(ImGui::Button("Aim", ImVec2(130, 50))){
                        pg1 = true;
                        pg2 = false;
                        pg3 = false;
                        pg4 = false;
                        pg5 = false;
                        pg6 = false;
                    }
                    if(ImGui::Button("Skins", ImVec2(130, 50))){
                        pg1 = false;
                        pg2 = true;
                        pg3 = false;
                        pg4 = false;
                        pg5 = false;
                        pg6 = false;
                    }
                }
                
                if(ImGui::CollapsingHeader("Rage")){
                    if(ImGui::Button("Sosalka", ImVec2(130, 50))){
                        pg1 = false;
                        pg2 = false;
                        pg3 = true;
                        pg4 = false;
                        pg5 = false;
                        pg6 = false;
                    }
                    if(ImGui::Button("Drochka", ImVec2(130, 50))){
                        pg1 = false;
                        pg2 = false;
                        pg3 = false;
                        pg4 = true;
                        pg5 = false;
                        pg6 = false;
                    }
                }
                
                if(ImGui::CollapsingHeader("Visual")){
                    if(ImGui::Button("Chams", ImVec2(130, 50))){
                        pg1 = false;
                        pg2 = false;
                        pg3 = false;
                        pg4 = false;
                        pg5 = true;
                        pg6 = false;
                    }
                }
            ImGui::EndChild();
            
            Style.Colors[ImGuiCol_Button] = ImColor(38, 38, 38, 255);
            Style.Colors[ImGuiCol_ButtonHovered] = ImColor(255, 140, 0, 255);
            Style.Colors[ImGuiCol_ButtonActive] = ImColor(255, 140, 0, 255);
            
            if(pg5){
                ImGui::SetCursorPos(ImVec2(167, 5));
                ImGui::BeginChild(2, ImVec2(625, 585), false);
		    	    
                if (ImGui::CollapsingHeader("shading ##chams")) {
                    ImGui::Spacing();
                    ImGui::Checkbox("enable ##shading", &enableWallhackS);
                    ImGui::Spacing();
                    ImGui::SliderFloat("red ##sh", &reds, 0, 255);
                    ImGui::SliderFloat("green ##sh", &greens, 0, 255);
                    ImGui::SliderFloat("blue ##sh", &blues, 0, 255);
                    ImGui::Separator();
                }
                
                    ImGui::Separator();
            
                if (ImGui::CollapsingHeader("wireframe ##chams")) {
                    ImGui::Spacing();
                    ImGui::Checkbox("enable ##wire", &enableWallhackW);
                    ImGui::SliderFloat("line ##wire", &wfwidth, 0, 5);
                    ImGui::Spacing();
                    ImGui::SliderFloat("red ##wire", &redw, 0, 255);
                    ImGui::SliderFloat("green ##wire", &greenw, 0, 255);
                    ImGui::SliderFloat("blue ##wire", &bluew, 0, 255);
                    //ImGui::SliderFloat("alpha ##wire", &wfalpha, 0, 255);
                    ImGui::Separator();
                }
                
                    ImGui::Separator();
                
                if (ImGui::CollapsingHeader("glow ##chams")) {
                    ImGui::Spacing();
                    ImGui::Checkbox("enable ##glow", &enableWallhackG);
                    ImGui::SliderFloat("line ##glow", &outwidth, 0, 5);
                    ImGui::Spacing();
                    ImGui::SliderFloat("red ##glow", &redg, 0, 255);
                    ImGui::SliderFloat("green ##glow", &greeng, 0, 255);
                    ImGui::SliderFloat("blue ##glow", &blueg, 0, 255);
                    ImGui::Separator();
                }
                
                    ImGui::Separator();
                    
                if (ImGui::CollapsingHeader("outline ##chams")) {
                    ImGui::Spacing();
                    ImGui::Checkbox("enable ##out", &enableWallhackO);
                    ImGui::SliderFloat("line ##out", &outwidth, 0, 10);
                    ImGui::Spacing();
                    ImGui::SliderFloat("red ##out", &redo, 0, 255);
                    ImGui::SliderFloat("green ##out", &greeno, 0, 255);
                    ImGui::SliderFloat("blue ##out", &blueo, 0, 255);
                    ImGui::Separator();
                }
                
                    ImGui::Separator();
                
                if (ImGui::CollapsingHeader("world ##chams")) {
                    ImGui::Text("Environment");
                    ImGui::Checkbox("World Color", &nightbool);
                    if (nightbool) {
                        nightvaltoggle = true;
                    } else {
                        nightvaltoggle = false;
                    }
                    ImGui::SliderFloat("r", &nightvalr, 0.0f, 255.0f);
                    ImGui::SliderFloat("g", &nightvalg, 0.0f, 255.0f);
                    ImGui::SliderFloat("b", &nightvalb, 0.0f, 255.0f);
				}
                    
                ImGui::EndChild();
            }
            
	}
	ImGui::End();
}


void DrawOpen(){
	//ImGui::CreateNewWindow(" ", ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar);
	ImGui::SetNextWindowSize(ImVec2(90, 90), ImGuiCond_Once);
	
	if(!ImGui::Begin(OBFUSCATE("@root_kalina"), NULL, ImGuiWindowFlags_NoResize /*| ImGuiWindowFlags_NoCollapse */| ImGuiWindowFlags_NoTitleBar)){
		
		/*if(ImGui::Button(OBFUSCATE("OPEN"), ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y))) {
            openMenuuuu = !openMenuuuu;
        }*/
		
		ImGui::End();
		return;
	}
	
	auto& Style = ImGui::GetStyle();
    
    Style.Colors[ImGuiCol_Button] = ImVec4(0, 0, 0, 0.000f);
    Style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.6f, 0.6f, 0.6f, 0.0f);
    Style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.6f, 0.6f, 0.6f, 0.0f);
    
		
	if(ImGui::Button(OBFUSCATE("MENU"), ImVec2(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y))) {
        openMenuuuu = !openMenuuuu;
    }
	
	/*ImVec2 P1, P2;
	ImDrawList* pDrawList;
	const auto& CurrentWindowPos = ImGui::GetWindowPos();
	const auto& pWindowDrawList = ImGui::GetWindowDrawList();
	const auto& pBackgroundDrawList = ImGui::GetBackgroundDrawList();
	const auto& pForegroundDrawList = ImGui::GetForegroundDrawList();
	
	F1 = ImVec2(0.000f, 85.000f);
	F1.x += CurrentWindowPos.x;
	F1.y += CurrentWindowPos.y;
	F2 = ImVec2(740.000f, 90.000f);
	F2.x += CurrentWindowPos.x;
	F2.y += CurrentWindowPos.y;
	pDrawList = pWindowDrawList;
	pDrawList->AddRectFilled(F1, F2, ImColor(255,75,75,255), 20);
	*/
		
	ImGui::End();
}


void initWeave()
{
  
  auto& Style = ImGui::GetStyle();
  
  

  Style.Colors[ImGuiCol_WindowBg] = ImVec4(0.07f, 0.07f, 0.07f, 1.0f);
  Style.Colors[ImGuiCol_ChildBg] = ImVec4(0.07f, 0.07f, 0.07f, 0.000f);
  Style.Colors[ImGuiCol_PopupBg] = ImVec4(0.07f, 0.07f, 0.07f, 0.940f);
  Style.Colors[ImGuiCol_Border] = ImVec4(0.5f, 0.5f, 0.5f, 0.500f);
  Style.Colors[ImGuiCol_FrameBg] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);
  Style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.6f, 0.6f, 0.6f, 0.75f);
  Style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.6f, 0.6f, 0.6f, 0.75f);
  Style.Colors[ImGuiCol_TitleBg] = ImVec4(0.525f, 0.000f, 0.522f, 1.000f);
  Style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.675f, 0.013f, 0.801f, 1.000f);
  Style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.300f, 0.009f, 0.343f, 0.232f);
  Style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.4f, 0.4f, 0.4f, 0.500f);
  Style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.020f, 0.020f, 0.020f, 0.000f);
  Style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.4f, 0.4f, 0.4f, 0.500f);
  Style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.6f, 0.6f, 0.6f, 0.75f);
  Style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.6f, 0.6f, 0.6f, 0.75f);
  Style.Colors[ImGuiCol_CheckMark] = ImColor(255, 140, 0, 255);
  Style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);
  Style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.6f, 0.6f, 0.6f, 0.75f);
  Style.Colors[ImGuiCol_Button] = ImVec4(0.4f, 0.4f, 0.4f, 0.500f);
  Style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.6f, 0.6f, 0.6f, 0.750f);
  Style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.6f, 0.6f, 0.6f, 0.750f);
  Style.Colors[ImGuiCol_Header] = ImColor(0,0,0,0);
  Style.Colors[ImGuiCol_HeaderHovered] = ImColor(0,0,0,0);
  Style.Colors[ImGuiCol_HeaderActive] = ImColor(0,0,0,0);
  Style.Colors[ImGuiCol_Separator] = ImColor(255, 140, 0, 255);
  Style.Colors[ImGuiCol_SeparatorHovered] = ImColor(255, 140, 0, 255);
  Style.Colors[ImGuiCol_SeparatorActive] = ImColor(255, 140, 0, 255);
  Style.Colors[ImGuiCol_ResizeGrip] = ImVec4(0.566f, 0.205f, 0.619f, 0.569f);
  Style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(0.759f, 0.193f, 0.796f, 0.670f);
  Style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.000f, 0.260f, 0.898f, 0.950f);
  Style.Colors[ImGuiCol_Tab] = ImVec4(0.446f, 0.167f, 0.464f, 0.862f);
  Style.Colors[ImGuiCol_TabHovered] = ImVec4(0.680f, 0.222f, 0.647f, 0.800f);
  Style.Colors[ImGuiCol_TabActive] = ImVec4(0.807f, 0.263f, 0.786f, 1.000f);
  Style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.236f, 0.122f, 0.276f, 0.972f);
  Style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.424f, 0.136f, 0.346f, 1.000f);
  Style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);
  Style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.4f, 0.4f, 0.4f, 0.5f);

  //Style.Colors[ImGuiCol_WindowBg] = ImVec4(0.376f, 0.050f, 0.352f, 0.940f);
  //Style.Colors[ImGuiCol_CheckMark] = ImVec4(1.000f, 0.000f, 0.895f, 1.000f);
}



#define HOOKAF(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)

HOOKAF(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent *)thiz);
    return;
}

void SetupImgui() {
    // Setup Dear ImGui context
    IMGUI_CHECKVERSION();

    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    io.DisplaySize = ImVec2((float)glWidth, (float)glHeight);

    // Setup Dear ImGui style
    // Setup Platform/Renderer backends
    ImGui_ImplOpenGL3_Init("#version 100");
	
	initWeave();

    // We load the default font with increased size to improve readability on many devices with "high" DPI.
    ImFontConfig font_cfg;
    font_cfg.SizePixels = 22.0f;
    io.Fonts->AddFontDefault(&font_cfg);

    // Arbitrary scale-up
    ImGui::GetStyle().ScaleAllSizes(scaleEz);
}










struct IdWeapin0231 {
    int None = 0;
    int G22 = 11;
    int USP = 12;
    int P350 = 13;
    int Deagle = 15;
    int Tec9 = 16;
    int FiveSeven = 17;
    int UMP45 = 32;
    int MP7 = 34;
    int P90 = 35;
    int MP5 = 36;
    int MAC10 = 37;
    int M4A1 = 43;
    int AKR = 44;
    int AKR12 = 45;
    int M4 = 46;
    int M16 = 47;
    int FAMAS = 48;
    int FnFal = 49;
    int AWM = 51;
    int M40 = 52;
    int M110 = 53;
    int SM1014 = 62;
    int FabM = 63;
    int M60 = 64;
    int SPAS = 65;
    int Knife = 70;
    int KnifeBayonet = 71;
    int KnifeKarambit = 72;
    int jKommando = 73;
    int KnifeButterfly = 75;
    int FlipKnife = 77;
    int KunaiKnife = 78;
    int ScorpionKnife = 79;
    int KnifeTanto = 80;
    int DaggerKnife = 81;
    int KnifeKukri = 82;
	int KnifeStilet = 83;
    int GrenadeHE = 91;
    int GrenadeSmoke = 92;
    int GrenadeFlash = 93;
    int Bomb = 100;
    int Defuser = 101;
    int DefuseKit = 102;
    int Vest = 110;
    int VestAndHelmet = 111;
    int Watergun = 19;
    int GrenadeSnowball = 99;
    int CandyCane = 84;
    int Minigun = 41;
    int ZombieHands = 83;
    } idweap;
    
    
int (*old_EquipedKnife)(void *instance);
int EquipedKnife(void *instance) {

    if (knifern == 0) { 
    return 70; //default
    } else if (knifern == 1) {
    return 72; //karambit
    } else if (knifern == 2) {
    return 71; //m9
    }
    return old_EquipedKnife(instance);
}

int weaponId = 70;

int (*old_EquipedSkin)(void *instance, int weaponId);
int EquipedSkin(void *instance, int weaponId) {
    if (knifern == 2 && weaponId == 71) {
        int returns = 0;
        if(m9rn == 0){
        returns = 220022;
        }
        if(m9rn == 1){
        returns = 71005;
        }
        if(m9rn == 2){
        returns = 71002;
        }
        if(m9rn == 3){
        returns = 71004;
        }
        if(m9rn == 4){
        returns = 71003;
        }
        if(m9rn == 5){
        returns = 71001;
        }             
        if(m9rn == 6){
        returns = 200012;
        }
        if(m9rn == 7){
        returns = 157100;
        }
        if(m9rn == 8){
        returns = 97100;
        }
        return returns;
    } else if (knifern == 1 && weaponId == 72) {
        int returns = 0;
        if(karambitrn == 0){
        returns = 220022;
        }
        if(karambitrn == 1){
        returns = 72004;
        }
        if(karambitrn == 2){
        returns = 72003;
        }
        if(karambitrn == 3){
        returns = 72007;
        }
        if(karambitrn == 4){
        returns = 72006;
        }
        if(karambitrn == 5){
        returns = 72002;
        }          
        return returns;
    } 
	return old_EquipedSkin(instance, weaponId);
}






EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);

    if (!setup) {
        SetupImgui();
        setup = true;
    }

    ImGuiIO &io = ImGui::GetIO();


    // Start the Dear ImGui frame
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    DrawMenu();
	DrawOpen();
	AntiBan();
    ImGui::EndFrame();
    ImGui::Render();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());


    return old_eglSwapBuffers(dpy, surface);
}

void threadhooks() {
    //methods
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x1440FE8"))), (void *) PlayerController, (void **) &old_PlayerController);
    DobbyHook((void *) KittyMemory::getAbsoluteAddress(libNames, string2Offset(OBFUSCATE("0x2819AC4"))), (void *) air_jump_system, (void **) &old_air_jump_system_general);
    IsLocal = (bool (*)(void *)) KittyMemory::getAbsoluteAddress(libNames,(string2Offset(OBFUSCATE("0x292AFC8"))));

    //hexs
    hexPatches.ChamsBypass = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x20B5A88")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Clumsy = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x29CFC74")), OBFUSCATE("00 00 00 00"));

	hexPatches.Aban1 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x247811C")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban2 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x24784E8")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban3 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x24768B0")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban4 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x2476C34")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban5 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x247741C")), OBFUSCATE("1E FF 2F E1"));
	hexPatches.Aban6 = MemoryPatch::createWithHex(OBFUSCATE("lib/arm/libil2cpp.so"), string2Offset(OBFUSCATE("0x2477618")), OBFUSCATE("1E FF 2F E1"));
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    do {
        sleep(1);
    } while (!isLibraryLoaded("libil2cpp.so"));
    //init shaders
    setShader(OBFUSCATE("_BumpMap"));
    mlovinit();
    LogShaders();
    Wallhack();
    threadhooks();
    pthread_exit(nullptr);
    return nullptr;
	
	DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x2F4ED6C"))), (void*)EquipedSkin, (void**)&old_EquipedSkin);
    DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x2F51924"))), (void*)EquipedKnife, (void**)&old_EquipedKnife);
    //DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x87FF70"))), (void*)setGloves, (void**)&old_setGloves);


	
}

void *imgui_go(void *) {
    address = findLibrary("libil2cpp.so");
    auto addr = (uintptr_t)dlsym(RTLD_NEXT, "eglSwapBuffers");
    DobbyHook((void *)addr, (void *)hook_eglSwapBuffers, (void **)&old_eglSwapBuffers);
    pthread_exit(nullptr);
    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
	    void *sym_input = DobbySymbolResolver(("/system/lib/libinput.so"), ("_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE"));
    if (NULL != sym_input) {
        DobbyHook((void *)sym_input, (void *) myInput, (void **)&origInput);
    }
    DobbyHook((void*)KittyMemory::getAbsoluteAddress(libName, string2Offset(OBFUSCATE("0x1B0736C"))), (void *) touches, (void **) &old_touches);
    pthread_t ptid;
    pthread_create(&ptid, NULL, imgui_go, NULL);
    pthread_t hacks;
    pthread_create(&hacks, NULL, hack_thread, NULL);
}



