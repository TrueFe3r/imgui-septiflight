#ifndef NORKA_CHAMS
#define NORKA_CHAMS
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <dlfcn.h>
#include "Substrate/SubstrateHook.h"
#include "Substrate/CydiaSubstrate.h"

static void *handle;
static const char* shaderName;
static bool enableWallhack;
static bool enableWallhackW;
static bool enableWallhackS;
static bool enableWallhackG;
static bool PulseT1;
static bool PulseT2;
static bool PulseW;
static bool PulseG;
static bool PulseA;
static bool enableWallhackO;
static bool enableSkyColor;
static bool enableRainbow;
static bool enableRainbow1;
static float r = 47.0f;
static float g = 158.0f;
static float b = 77.0f;
static int w = 2;
static float gw = 7.0f;
static float ow = 6.0f;
static int a = 255;

float red = 47.0f;
float gren = 158.0f;
float blue = 77.0f;
float mi = 0.0f;

float redw = 47.0f;
float greenw = 158.0f;
float bluew = 77.0f;
float wfwidth = 2.5f;

float texturedr, texturedg, texturedb, reds, greens, blues, redo, blueo, greeno, redg, blueg, greeng, redt, bluet, greent,
        wfalpha, glowwidth, outwidth = 0.0f;

int pulsevalue = 255;


void setShader(const char* s) {
    handle = dlopen("libGLESv2.so", RTLD_LAZY);
    shaderName = s;
}

const char* getShader() {
    return shaderName;
}


void PulseT1Set(bool enable) {
    PulseT1 = enable;
}
void PulseT2Set(bool enable) {
    PulseT2 = enable;
}
void PulseWSet(bool enable) {
    PulseW = enable;
}
void PulseGSet(bool enable) {
    PulseG = enable;
}
void PulseASet(bool enable) {
    PulseA = enable;
}

void SetWallhack(bool enable){
    enableWallhack = enable;
}

void SetWireframe(bool enable){
    enableWallhackW = enable;
}

void SetShading(bool enable){
    enableWallhackS = enable;
}

void SetGlow(bool enable){
    enableWallhackG = enable;
}

void SetOutline(bool enable){
    enableWallhackO = enable;
}

void SetSkyColor(bool enable){
    enableSkyColor = enable;
}

void SetRainbow(bool enable){
    enableRainbow = enable;
}
void SetRainbow1(bool enable){
    enableRainbow1 = enable;
}


void SetR(int set){
    r = set;
}

void SetG(int set){
    g = set;
}

void SetB(int set){
    b = set;
}

void SetWireframeWidth(int set){
    w = set;
}

void SetGlowWidth(int set){
    gw = set;
}

void SetOutlineWidth(int set){
    ow = set;
}


bool getWallhackEnabled(){
    return enableWallhack;
}

bool getWireframeEnabled(){
    return enableWallhackW;
}

bool getShadingEnabled(){
    return enableWallhackS;
}

bool getGlowEnabled(){
    return enableWallhackG;
}

bool getOutlineEnabled(){
    return enableWallhackO;
}

bool getRainbowEnabled(){
    return enableRainbow;
}
bool getRainbow1Enabled(){
    return enableRainbow1;
}

int (*old_glGetUniformLocation)(GLuint, const GLchar *);
GLint new_glGetUniformLocation(GLuint program, const GLchar *name) {
    return old_glGetUniformLocation(program, name);
}

bool isCurrentShader(const char *shader) {
    GLint currProgram;
    glGetIntegerv(GL_CURRENT_PROGRAM, &currProgram);
    return old_glGetUniformLocation(currProgram, shader) != -1;
}

bool nightvaltoggle = false;
float nightvalr, nightvalb, nightvalg = 0.0f;

void (*old_glDrawElements)(GLenum mode, GLsizei count, GLenum type, const void *indices);
void new_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void *indices) {
    old_glDrawElements(mode, count, type, indices);
    if (mode != GL_TRIANGLES || count < 1000) return;
    {
        GLint currProgram;
        glGetIntegerv(GL_CURRENT_PROGRAM, &currProgram);
        GLint id = old_glGetUniformLocation(currProgram, getShader());

        GLint currProgram2;
        glGetIntegerv(GL_CURRENT_PROGRAM, &currProgram);
        GLint id2 = old_glGetUniformLocation(currProgram, "_MainTex");

        if (id2 != -1 && id == -1) {
            if (mode != GL_TRIANGLES || count < 1) return;
            if (nightvaltoggle) {
                glBlendColor(GLfloat(1 - float(nightvalr) / 200), GLfloat(1 - float(nightvalg) / 200), GLfloat(1 - float(nightvalb) / 200), 0);
                glColorMask(1, 1, 1, 1);
                glEnable(GL_BLEND);
                glBlendFuncSeparate(GL_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE, GL_ZERO);
                old_glDrawElements(GL_TRIANGLES, count, type, indices);
            }
        }

        if (id == -1){ old_glDrawElements(mode, count, type, indices); return;}
        old_glDrawElements(mode, count, type, indices);
        if (getWireframeEnabled()) {

            if (enableWallhackW) {
                glDepthRangef(1, 0.5);
            }
            else {
                glDepthRangef(0.5, 1);
            }
            glBlendColor(GLfloat(redw/255), GLfloat(greenw/255), GLfloat(bluew/255), 1);
            glColorMask(1, 1, 1, 1);
            glEnable(GL_BLEND);
            glBlendFuncSeparate(GL_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE, GL_ZERO);
            glLineWidth(wfwidth);
            old_glDrawElements(GL_LINE_LOOP, count, type, indices);
        }


        if (getWallhackEnabled()) {
            glDepthRangef(1, 0.5);
            glBlendColor(GLfloat(texturedr/255), GLfloat(texturedg/255), GLfloat(texturedb/255), GLfloat(wfalpha/255));
            glColorMask(r, g, b, 255);
            glEnable(GL_BLEND);
            glBlendFunc(GL_CONSTANT_ALPHA, GL_CONSTANT_COLOR);
        }

        if (getGlowEnabled()) {
            glEnable(GL_BLEND);
            glBlendColor(GLfloat(redg/255), GLfloat(greeng/255), GLfloat(blueg/255), 1);
            glColorMask(1, 1, 1, 1);
            glEnable(GL_BLEND);
            glBlendFuncSeparate(GL_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE, GL_ZERO);
            glLineWidth(6);
            glDepthRangef(0.5, 1);
            old_glDrawElements(GL_LINES, count, type, indices);
            glBlendColor(1, 1, 1, 1);
            glDepthRangef(1, 0.5);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
        }

        if (getShadingEnabled()) {
            glDepthRangef(1, 0.5);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_COLOR, GL_CONSTANT_COLOR);
            glBlendEquation(GL_FUNC_ADD);
            glBlendColor(GLfloat(reds/255), GLfloat(greens/255), GLfloat(blues/255), 1);
            glDepthFunc(GL_ALWAYS);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glColorMask(reds, greens, blues, 255);
            glBlendFunc(GL_DST_COLOR, GL_ONE);
            glDepthFunc(GL_LESS);
            glBlendColor(0.0, 0.0, 0.0, 0.0);
        }

        if (getOutlineEnabled()) {
            glDepthRangef(1, 0);
            glLineWidth(ow);
            glEnable(GL_BLEND);
            glColorMask(1, 1, 1, 1);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            glBlendFuncSeparate(GL_CONSTANT_COLOR, GL_CONSTANT_ALPHA, GL_ONE, GL_ZERO);
            glBlendColor(0, 0, 0, 1);
            old_glDrawElements(GL_TRIANGLES, count, type, indices);
            glBlendColor(GLfloat(redo/100), GLfloat(greeno/100), GLfloat(blueo/100), 1);
            glDepthRangef(1, 0.5);
            glBlendColor(GLfloat(float(redo)/255), GLfloat(float(greeno)/255), GLfloat(float(blueo)/255), 1);
            old_glDrawElements(GL_LINES, count, type, indices);
        }

        if (getRainbowEnabled()) {
            if(getRainbow1Enabled){
                if (red == 255){
                    if (blue == 0 ){
                        if (gren == 255){} else{
                            gren = gren+1;
                        }
                    }
                }
                if (gren == 255){
                    if (red == 0){} else{
                        red = red-1;
                    }
                }
                if (gren == 255) {
                    if (red == 0) {
                        if (blue==255){} else{
                            blue = blue+1;
                        }
                    }
                }
                if (blue == 255) {
                    if (gren == 0) {
                        mi = 1;
                        red = red+1;
                    }
                    else{
                        gren = gren-1;
                    }
                }
                if (mi == 1){
                    if (red == 255){
                        if (blue == 0){} else{
                            blue = blue-1;
                        }
                    }
                }
                SetR(red);
                SetG(gren);
                SetB(blue);
            }
            glBlendColor(GLfloat(r/255), GLfloat(g/255), GLfloat(b/255), GLfloat(a/255));
            glColorMask(1, 1, 1, 1);
            glEnable(GL_BLEND);
            glDepthRangef(1, 0.5);
            glBlendFunc(GL_ONE_MINUS_CONSTANT_COLOR, GL_ONE_MINUS_CONSTANT_ALPHA);
        }
        old_glDrawElements(mode, count, type, indices);

        glDepthRangef(0.5, 1);

        glColorMask(1, 1, 1, 1);
        glDisable(GL_BLEND);
    }
}

bool mlovinit(){
    handle = NULL;
    handle = dlopen("libGLESv2.so", RTLD_LAZY);
    if(!handle){
        //LOGE("Cannot open library: %s", dlerror());
        return false;
    }
    return true;
}

void LogShaders(){
    auto p_glGetUniformLocation = (const void*(*)(...))dlsym(handle, "glGetUniformLocation");
    const char *dlsym_error = dlerror();
    if(dlsym_error){
        //LOGE("Cannot load symbol 'glGetUniformLocation': %s", dlsym_error);
        return;
    }else{
        MSHookFunction(reinterpret_cast<void*>(p_glGetUniformLocation), reinterpret_cast<void*>(new_glGetUniformLocation), reinterpret_cast<void**>(&old_glGetUniformLocation));
    }
}

void Wallhack(){
    auto p_glDrawElements = (const void*(*)(...))dlsym(handle, "glDrawElements");
    const char *dlsym_error = dlerror();
    if(dlsym_error){
        //LOGE("Cannot load symbol 'glDrawElements': %s", dlsym_error);
        return;
    }else{
        MSHookFunction(reinterpret_cast<void*>(p_glDrawElements), reinterpret_cast<void*>(new_glDrawElements), reinterpret_cast<void**>(&old_glDrawElements));
    }
}

#endif
